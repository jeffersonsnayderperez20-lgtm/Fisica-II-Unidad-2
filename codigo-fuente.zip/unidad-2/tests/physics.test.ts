import { describe, it, expect } from "vitest";
import { runChecks } from "./cases";
import { electric, checkChargeSegment } from "../src/physics/electric";
import { capacitor } from "../src/physics/capacitor";
import { solveCircuit } from "../src/physics/circuit";
import { magnetic } from "../src/physics/magnetic";
import { boris } from "../src/physics/particle";
describe("Validación física y numérica", () => {
  for (const c of runChecks())
    it(c.name, () => expect(c.error).toBeLessThanOrEqual(c.tolerance));
});
describe("Casos límite del alcance", () => {
  it("rechaza separación cero", () =>
    expect(() => capacitor(1, 0, 1, 12)).toThrow());
});
