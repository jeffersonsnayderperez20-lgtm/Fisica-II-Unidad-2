# CampoLab - Unidad 2 - Capacitores y dieléctricos

Presento mi simulador de un capacitor ideal de placas paralelas. Incluyo React, TypeScript, Three.js, Recharts, el motor físico y cinco pruebas.

## Ejecutar

Requisitos: Node.js 22.12 o superior.

```bash
npm install
npm run dev
```

Abrir la dirección que imprime Vite. Para instalar usando el bloqueo incluido: pnpm 11.19.0 y `pnpm install --frozen-lockfile`.

## Comprobar y compilar

```bash
npm test
npm run build
npm run preview
```

El build genera dist; no se incluye en el ZIP de fuentes. Los documentos se entregan por separado en Drive. src/modules/Capacitor.tsx contiene la interfaz; src/physics/capacitor.ts calcula C, Q, V, U y E. Conservo la biblioteca física común por sus dependencias con el banco de pruebas.

## Límites

Placas ideales, dieléctrico lineal y homogéneo. No incluyo efectos de borde, pérdidas, ruptura ni transitorios. La escena amplifica longitudes laterales por 10 y separación por 200; los resultados se calculan en SI.
