import { useMemo, useState } from "react";
import { capacitor } from "../physics/capacitor";
import { Scene, type SceneData } from "../components/Scene";
import { Num, Panel, Metric } from "../components/Controls";
import { Plot } from "../components/Plot";
export function Capacitor() {
  const [A, setA] = useState(0.02),
    [d, setD] = useState(0.002),
    [er, setEr] = useState(2),
    [V, setV] = useState(12),
    [held, setHeld] = useState<number | undefined>();
  const r = capacitor(A, d, er, V, held),
    [unit, setUnit] = useState("nF");
  const data = useMemo<SceneData>(() => {
    const side = Math.sqrt(A) * 10,
      gap = d * 200;
    return {
      boxes: [
        {
          position: [0, 0, gap / 2],
          size: [side, side, 0.04],
          color: r.Q >= 0 ? "#ff9b80" : "#78b7ff",
        },
        {
          position: [0, 0, -gap / 2],
          size: [side, side, 0.04],
          color: r.Q >= 0 ? "#78b7ff" : "#ff9b80",
        },
        {
          position: [0, 0, 0],
          size: [side, side, Math.max(0.01, gap - 0.04)],
          color: "#70cbbd",
          opacity: er > 1 ? 0.18 : 0.02,
        },
      ],
      markers: [
        {
          position: [side / 2 + 0.3, 0, gap / 2],
          color: "#eee",
          label: r.Q >= 0 ? "+" : "−",
        },
        {
          position: [side / 2 + 0.3, 0, -gap / 2],
          color: "#eee",
          label: r.Q >= 0 ? "−" : "+",
        },
      ],
      arrows:
        r.E === 0
          ? []
          : [-0.3, 0, 0.3].flatMap((x) =>
              [-0.3, 0, 0.3].map((y) => ({
                position: [x * side, y * side, 0] as [number, number, number],
                direction: [0, 0, -Math.sign(r.E)] as [number, number, number],
                color: "#ffe18c",
              })),
            ),
    };
  }, [A, d, er, r.Q, r.E]);
  const graph = Array.from({ length: 30 }, (_, i) => {
    const sep = 0.0005 + i * 0.0005;
    return { x: sep * 1000, y: capacitor(A, sep, er, V, held).C * 1e9 };
  });
  const reset = () => {
    setA(0.02);
    setD(0.002);
    setEr(2);
    setV(12);
    setHeld(undefined);
  };
  return (
    <>
      <div className="module-toolbar">
        <span className="tag">Modelo de placas paralelas</span>
        <button onClick={reset}>Restablecer</button>
      </div>
      <div className="workspace">
        <Panel title="Geometría y materiales" className="parameters">
          <Num
            label="Área A (cm²)"
            value={A * 1e4}
            min={10}
            max={10000}
            onChange={(v) => setA(v / 1e4)}
          />
          <Num
            label="Separación d (mm)"
            value={d * 1000}
            min={0.1}
            max={15}
            onChange={(v) => setD(v / 1000)}
          />
          <Num
            label="Constante dieléctrica εᵣ"
            value={er}
            min={1}
            max={100}
            onChange={setEr}
          />
          <Num
            label="Voltaje de la fuente (V)"
            value={V}
            min={-10000}
            max={10000}
            onChange={setV}
            disabled={held !== undefined}
          />
          <label>
            Material ideal
            <select value="" onChange={(e) => setEr(+e.target.value)}>
              <option value="" disabled>
                Elegir εᵣ ilustrativa
              </option>
              <option value="1">Vacío · 1</option>
              <option value="2">Dieléctrico A · 2</option>
              <option value="4">Dieléctrico B · 4</option>
            </select>
          </label>
          <h3>Condición eléctrica</h3>
          <button
            className="primary full"
            onClick={() => setHeld(held === undefined ? r.Q : undefined)}
          >
            {held === undefined ? "Desconectar fuente" : "Reconectar fuente"}
          </button>
          <p>
            {held === undefined
              ? "Fuente conectada: V constante; la carga se ajusta a la capacitancia."
              : "Fuente desconectada: se conserva la carga capturada al desconectar; el voltaje cambia."}
          </p>
          <small>
            Al reconectar se impone el voltaje de la fuente. No se simula el
            transitorio de carga.
          </small>
        </Panel>
        <div className="main-column">
          <section className="visual-card">
            <div className="visual-heading">
              <span>CAPACITOR IDEAL</span>
              <span>{held === undefined ? "V CONSTANTE" : "Q CONSTANTE"}</span>
            </div>
            <Scene
              data={data}
              axisUnit="visual"
              title="Placas paralelas con dieléctrico y campo uniforme"
            />
            <div className="legend">
              Área visual ×10 en longitud · separación ×200 · dieléctrico
              translúcido
            </div>
          </section>
          <Panel title="Capacitancia y separación">
            <Plot data={graph} xLabel="d (mm)" yLabel="C (nF)" />
          </Panel>
        </div>
        <Panel title="Resultados" className="results">
          <label>
            Unidad de capacitancia
            <select value={unit} onChange={(e) => setUnit(e.target.value)}>
              <option>nF</option>
              <option>μF</option>
            </select>
          </label>
          <Metric
            label="Capacitancia C"
            value={r.C * (unit === "nF" ? 1e9 : 1e6)}
            unit={unit}
          />
          <Metric
            label="Carga en la placa positiva de referencia"
            value={r.Q * 1e9}
            unit="nC"
          />
          <Metric label="Voltaje entre placas" value={r.V} unit="V" />
          <Metric label="Energía almacenada U" value={r.U * 1e6} unit="μJ" />
          <Metric label="Campo firmado V/d" value={r.E} unit="V/m" />
          <div className="formula">
            C = ε₀ εᵣ A / d<br />Q = CV
            <br />U = ½ CV² = Q² / (2C)
          </div>
          <p>
            Placas conductoras, dieléctrico lineal que llena todo el espacio y
            campo uniforme. No se incluyen bordes, pérdidas ni ruptura
            dieléctrica.
          </p>
          {d / Math.sqrt(A) > 0.05 && (
            <p className="warning">
              d/√A &gt; 0,05: los efectos de borde podrían ser relevantes. El
              resultado corresponde al modelo ideal.
            </p>
          )}
          <p>
            Con Q constante, aumentar εᵣ reduce V y U. Con V constante, aumenta
            Q y U; la fuente intercambia energía.
          </p>
        </Panel>
      </div>
    </>
  );
}
