import { type Vec, add, scale, norm, unit } from "./vector";
export function trace(
  field: (p: Vec) => Vec,
  seeds: Vec[],
  extent = 4,
  step = 0.07,
  max = 220,
): Vec[][] {
  const lines: Vec[][] = [];
  for (const seed of seeds) {
    const halves: Vec[][] = [];
    for (const sign of [-1, 1]) {
      let p = seed;
      const path: Vec[] = [p];
      for (let i = 0; i < max; i++) {
        try {
          const f = field(p);
          if (norm(f) < 1e-25) break;
          const mid = add(p, scale(unit(f), (sign * step) / 2));
          p = add(p, scale(unit(field(mid)), sign * step));
          if (p.some((v) => Math.abs(v) > extent)) break;
          path.push(p);
          if (
            i > 15 &&
            norm([p[0] - seed[0], p[1] - seed[1], p[2] - seed[2]]) < step
          )
            break;
        } catch {
          break;
        }
      }
      halves.push(path);
    }
    lines.push([...halves[0].reverse(), ...halves[1].slice(1)]);
  }
  return lines;
}
/** Marching tetrahedra: interpolación lineal de V en cada tetraedro. */
export function isoSurface(
  f: (p: Vec) => number,
  level: number,
  extent = 3,
  resolution = 32,
): number[] {
  const n = resolution + 1,
    values = new Float64Array(n * n * n),
    points: Vec[] = [],
    idx = (x: number, y: number, z: number) => x + n * (y + n * z);
  for (let z = 0; z < n; z++)
    for (let y = 0; y < n; y++)
      for (let x = 0; x < n; x++) {
        const p: Vec = [
          -extent + (2 * extent * x) / resolution,
          -extent + (2 * extent * y) / resolution,
          -extent + (2 * extent * z) / resolution,
        ];
        points.push(p);
        try {
          values[idx(x, y, z)] = f(p);
        } catch {
          values[idx(x, y, z)] = NaN;
        }
      }
  const corners = [
    [0, 0, 0],
    [1, 0, 0],
    [1, 1, 0],
    [0, 1, 0],
    [0, 0, 1],
    [1, 0, 1],
    [1, 1, 1],
    [0, 1, 1],
  ];
  const tets = [
      [0, 5, 1, 6],
      [0, 1, 2, 6],
      [0, 2, 3, 6],
      [0, 3, 7, 6],
      [0, 7, 4, 6],
      [0, 4, 5, 6],
    ],
    edges = [
      [0, 1],
      [0, 2],
      [0, 3],
      [1, 2],
      [1, 3],
      [2, 3],
    ],
    out: number[] = [];
  for (let z = 0; z < resolution; z++)
    for (let y = 0; y < resolution; y++)
      for (let x = 0; x < resolution; x++) {
        const ids = corners.map(([a, b, c]) => idx(x + a, y + b, z + c));
        for (const tet of tets) {
          const ti = tet.map((i) => ids[i]);
          if (ti.some((i) => !Number.isFinite(values[i]))) continue;
          const hits: Vec[] = [];
          for (const [a, b] of edges) {
            const ia = ti[a],
              ib = ti[b],
              va = values[ia],
              vb = values[ib];
            if (va < level === vb < level) continue;
            const t = (level - va) / (vb - va);
            hits.push(add(scale(points[ia], 1 - t), scale(points[ib], t)));
          }
          if (hits.length === 3) out.push(...hits[0], ...hits[1], ...hits[2]);
          if (hits.length === 4)
            out.push(
              ...hits[0],
              ...hits[1],
              ...hits[2],
              ...hits[1],
              ...hits[3],
              ...hits[2],
            );
        }
      }
  return out;
}
/** Contornos por triangulación: evita la ambigüedad de celdas silla. */
export function contours(
  f: (p: Vec) => number,
  level: number,
  z = 0,
  n = 65,
): Vec[][] {
  const out: Vec[][] = [];
  const coord = (x: number, y: number): Vec => [
    -3 + (6 * x) / n,
    -3 + (6 * y) / n,
    z,
  ];
  const vals = Array.from({ length: n + 1 }, (_, y) =>
    Array.from({ length: n + 1 }, (_, x) => {
      try {
        return f(coord(x, y));
      } catch {
        return NaN;
      }
    }),
  );
  for (let y = 0; y < n; y++)
    for (let x = 0; x < n; x++)
      for (const tri of [
        [
          [x, y],
          [x + 1, y],
          [x + 1, y + 1],
        ],
        [
          [x, y],
          [x + 1, y + 1],
          [x, y + 1],
        ],
      ]) {
        const v = tri.map(([a, b]) => vals[b][a]);
        if (v.some((a) => !Number.isFinite(a))) continue;
        const hits: Vec[] = [];
        for (const [a, b] of [
          [0, 1],
          [1, 2],
          [2, 0],
        ])
          if (v[a] < level !== v[b] < level) {
            const t = (level - v[a]) / (v[b] - v[a]);
            hits.push(
              add(
                scale(coord(...(tri[a] as [number, number])), 1 - t),
                scale(coord(...(tri[b] as [number, number])), t),
              ),
            );
          }
        if (hits.length === 2) out.push(hits);
      }
  return out;
}
