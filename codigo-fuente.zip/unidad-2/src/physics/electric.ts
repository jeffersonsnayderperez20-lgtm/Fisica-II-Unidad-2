import { type Vec, sub, scale, add, norm, dot, K, EXCLUSION } from "./vector";
export interface Charge {
  id: number;
  q: number;
  position: Vec;
}
export function electric(
  charges: Charge[],
  p: Vec,
  exclusion = EXCLUSION,
): { E: Vec; V: number } {
  let E: Vec = [0, 0, 0],
    V = 0;
  for (const c of charges) {
    if (c.q === 0) continue;
    const d = sub(p, c.position),
      r = norm(d);
    if (r <= exclusion)
      throw Error("Punto dentro de la zona excluida de una carga (0,08 m).");
    E = add(E, scale(d, (K * c.q) / r ** 3));
    V += (K * c.q) / r;
  }
  return { E, V };
}
export const chargeExamples: Record<string, Charge[]> = {
  Dipolo: [
    { id: 1, q: 1e-9, position: [-1, 0, 0] },
    { id: 2, q: -1e-9, position: [1, 0, 0] },
  ],
  "Carga aislada": [{ id: 1, q: 1e-9, position: [0, 0, 0] }],
  "Varias cargas": [
    { id: 1, q: 1e-9, position: [-1, -1, 0] },
    { id: 2, q: -1e-9, position: [1, 1, 0] },
    { id: 3, q: 2e-9, position: [-1, 1, 0] },
    { id: 4, q: -1e-9, position: [1, -1, 0] },
  ],
};

/** Rechaza intersecciones de cada tramo de deriva con una esfera excluida. */
export function checkChargeSegment(charges: Charge[], a: Vec, b: Vec) {
  const d = sub(b, a),
    length2 = dot(d, d);
  for (const c of charges) {
    if (c.q === 0) continue;
    const t = length2
      ? Math.max(0, Math.min(1, dot(sub(c.position, a), d) / length2))
      : 0;
    if (norm(sub(add(a, scale(d, t)), c.position)) <= EXCLUSION)
      throw Error(
        "La trayectoria intersecta una zona excluida de carga. Reinicia desde otra posición o dirección.",
      );
  }
}
