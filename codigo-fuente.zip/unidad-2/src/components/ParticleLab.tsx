import { useEffect, useMemo, useRef, useState } from "react";
import { Scene, type SceneData } from "./Scene";
import { Num, Panel, VectorInput, Metric, fmt } from "./Controls";
import { Plot } from "./Plot";
import {
  boris,
  gyroRadius,
  type Particle,
  type Fields,
} from "../physics/particle";
import { add, scale, cross, norm, sub, type Vec } from "../physics/vector";
const empty: SceneData = {};
export function ParticleLab({
  externalFields,
  background = empty,
  validateSegment,
}: {
  externalFields?: Fields;
  background?: SceneData;
  validateSegment?: (a: Vec, b: Vec) => void;
}) {
  const electricOnly = !!externalFields;
  const [q, setQ] = useState(electricOnly ? 1e-9 : 1e-6),
    [m, setM] = useState(electricOnly ? 1e-8 : 1e-9),
    [x, setX] = useState<Vec>(electricOnly ? [0, 1, 0] : [0, 0, 0]),
    [v, setV] = useState<Vec>([1, 0, 0]);
  const [E, setE] = useState<Vec>([0, 0, 0]),
    [B, setB] = useState<Vec>([0, 0, 0.001]),
    [dt, setDt] = useState(0.01),
    [speed, setSpeed] = useState(1),
    [running, setRunning] = useState(false),
    [error, setError] = useState("");
  const fields = useMemo<Fields>(
    () => externalFields ?? (() => ({ E, B })),
    [externalFields, E, B],
  );
  const initial = useMemo<Particle>(
    () => ({ q, m, position: x, velocity: v }),
    [q, m, x, v],
  );
  const state = useRef({
    p: initial,
    t: 0,
    trail: [x],
    history: [{ x: 0, y: norm(v) }],
  });
  const [snapshot, setSnapshot] = useState(state.current);
  const reset = () => {
    state.current = {
      p: initial,
      t: 0,
      trail: [x],
      history: [{ x: 0, y: norm(v) }],
    };
    setSnapshot({ ...state.current });
    setRunning(false);
    setError("");
  };
  useEffect(reset, [initial, fields, dt]);
  const advance = () => {
    try {
      const s = state.current,
        f = fields(s.p.position);
      if ((Math.abs(q) * norm(f.B) * dt) / m > 0.2)
        throw Error(
          "Paso demasiado grande: requiere |q| |B| Δt / m ≤ 0,2. Reduce Δt.",
        );
      const next = boris(s.p, dt, fields, validateSegment);
      if (electricOnly && norm(sub(next.position, s.p.position)) > 0.04)
        throw Error(
          "Desplazamiento > 0,04 m por paso. Reduce Δt para resolver el campo cerca de las cargas.",
        );
      if (next.position.some((a) => Math.abs(a) > 30))
        throw Error(
          "Partícula fuera del dominio de seguimiento (±30 m). Reinicia o ajusta la velocidad.",
        );
      state.current = {
        p: next,
        t: s.t + dt,
        trail: [...s.trail.slice(-2998), next.position],
        history: [
          ...s.history.slice(-299),
          { x: s.t + dt, y: norm(next.velocity) },
        ],
      };
      return true;
    } catch (e) {
      setError((e as Error).message);
      setRunning(false);
      return false;
    }
  };
  useEffect(() => {
    if (!running) return;
    let id = 0,
      last = performance.now(),
      acc = 0;
    const tick = (now: number) => {
      acc += Math.min((now - last) / 1000, 0.1) * speed * 0.4;
      last = now;
      let count = 0;
      while (acc >= dt && count < 500) {
        if (!advance()) {
          setSnapshot({ ...state.current });
          return;
        }
        acc -= dt;
        count++;
      }
      setSnapshot({ ...state.current });
      id = requestAnimationFrame(tick);
    };
    id = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(id);
  }, [running, dt, speed, fields, q, m, validateSegment]);
  const preset = (kind: string) => {
    setQ(1e-6);
    setM(1e-9);
    setX([0, 0, 0]);
    setB([0, 0, 0.001]);
    setE(kind === "Cruzados" ? [0, 0.001, 0] : [0, 0, 0]);
    setV(
      kind === "Helicoidal"
        ? [1, 0, 0.35]
        : kind === "Cruzados"
          ? [0, 0, 0]
          : [1, 0, 0],
    );
    setDt(0.01);
  };
  let force: Vec = [0, 0, 0],
    fieldError = "";
  try {
    const f = fields(snapshot.p.position);
    force = scale(add(f.E, cross(snapshot.p.velocity, f.B)), q);
  } catch (e) {
    fieldError = (e as Error).message;
  }
  return (
    <div className="workspace">
      <Panel title="Partícula de prueba" className="parameters">
        {!electricOnly && (
          <div className="preset-row">
            {["Circular", "Helicoidal", "Cruzados"].map((k) => (
              <button key={k} onClick={() => preset(k)}>
                {k}
              </button>
            ))}
          </div>
        )}
        <Num
          label="Carga q (μC, con signo)"
          value={q / 1e-6}
          onChange={(v) => setQ(v * 1e-6)}
          min={-100}
          max={100}
        />
        <Num
          label="Masa m (kg)"
          value={m}
          onChange={setM}
          min={1e-15}
          max={1}
        />
        <VectorInput
          label="Posición inicial (m)"
          value={x}
          onChange={setX}
          min={-3}
          max={3}
        />
        <VectorInput
          label="Velocidad inicial (m/s)"
          value={v}
          onChange={setV}
          min={-1000}
          max={1000}
        />
        {!electricOnly && (
          <>
            <VectorInput
              label="Campo E (V/m)"
              value={E}
              onChange={setE}
              min={-100}
              max={100}
            />
            <VectorInput
              label="Campo B (mT)"
              value={B}
              onChange={setB}
              factor={0.001}
              min={-100}
              max={100}
            />
          </>
        )}
        <Num
          label="Paso físico Δt (s)"
          value={dt}
          onChange={setDt}
          min={0.00001}
          max={0.1}
        />
        <label>
          Reproducción ×{speed}
          <input
            type="range"
            min="0.25"
            max="5"
            step="0.25"
            value={speed}
            onChange={(e) => setSpeed(+e.target.value)}
          />
        </label>
        <small>
          ×1 reproduce 0,4 s físicos por segundo real. Cambiar parámetros
          reinicia la trayectoria.
        </small>
      </Panel>
      <div className="main-column">
        <section className="visual-card">
          <div className="visual-heading">
            <span>TRAYECTORIA · BORIS</span>
            <span>SI · tiempo simulado</span>
          </div>
          <Scene
            data={background}
            trail={snapshot.trail}
            particle={snapshot.p.position}
            title="Trayectoria numérica de una partícula cargada"
          />
          <div className="playback">
            <button
              className="primary"
              disabled={!!fieldError}
              onClick={() => {
                setError("");
                setRunning(!running);
              }}
            >
              {running ? "Pausar" : "Iniciar"}
            </button>
            <button
              disabled={running || !!fieldError}
              onClick={() => {
                setError("");
                advance();
                setSnapshot({ ...state.current });
              }}
            >
              Un paso
            </button>
            <button onClick={reset}>Reiniciar</button>
            <strong>t = {fmt(snapshot.t, "s")}</strong>
          </div>
        </section>
        {(error || fieldError) && (
          <p className="error-box" role="alert">
            {error || fieldError}
          </p>
        )}
        <Panel title="Rapidez a lo largo del tiempo">
          <Plot data={snapshot.history} xLabel="t (s)" yLabel="|v| (m/s)" />
        </Panel>
      </div>
      <Panel title="Resultados y modelo" className="results">
        <Metric label="Rapidez" value={norm(snapshot.p.velocity)} unit="m/s" />
        <Metric label="Fuerza de Lorentz |F|" value={norm(force)} unit="N" />
        <Metric
          label="Energía cinética"
          value={0.5 * m * norm(snapshot.p.velocity) ** 2}
          unit="J"
        />
        {!electricOnly && (
          <Metric
            label="Radio teórico con E = 0"
            value={gyroRadius(initial, B)}
            unit="m"
          />
        )}
        <p className="formula">F = q(E + v × B)</p>
        <p>
          Posición actual (m):{" "}
          {snapshot.p.position.map((a) => fmt(a)).join("; ")}.
        </p>
        <p>
          {electricOnly
            ? "Campo de las cargas fijas. La partícula no modifica las fuentes."
            : "Campos uniformes externos. Con E = 0, la fuerza magnética cambia la dirección y conserva la rapidez."}
        </p>
        <p>
          La deriva media, el impulso eléctrico y la rotación de Boris separan
          el paso físico del dibujo. Reducir Δt permite evaluar el error de
          fase.
        </p>
        <small>
          Sin relatividad, radiación ni colisiones. Estela: últimos 3000 puntos.
          Gráfico: últimos 300 pasos. Un radio indefinido se muestra como —.
        </small>
      </Panel>
    </div>
  );
}
