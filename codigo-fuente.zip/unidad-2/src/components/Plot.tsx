import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
} from "recharts";
export function Plot({
  data,
  xLabel,
  yLabel,
  xKey = "x",
  yKey = "y",
  point,
}: {
  data: Record<string, number>[];
  xLabel: string;
  yLabel: string;
  xKey?: string;
  yKey?: string;
  point?: { x: number; y: number };
}) {
  return (
    <div
      className="plot"
      role="img"
      aria-label={`${yLabel} en función de ${xLabel}`}
    >
      <ResponsiveContainer width="100%" height={230}>
        <LineChart
          data={data}
          margin={{ top: 10, right: 24, left: 12, bottom: 24 }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#dfe6ec" />
          <XAxis
            type="number"
            dataKey={xKey}
            label={{ value: xLabel, position: "bottom", offset: 3 }}
            tickFormatter={(v) => Number(v).toPrecision(3)}
          />
          <YAxis
            label={{
              value: yLabel,
              angle: -90,
              position: "insideLeft",
              offset: 0,
            }}
            tickFormatter={(v) => Number(v).toPrecision(3)}
          />
          <Tooltip
            formatter={(v) => (typeof v === "number" ? v.toPrecision(5) : v)}
          />
          <Line
            dataKey={yKey}
            name={yLabel}
            stroke="#078677"
            dot={false}
            isAnimationActive={false}
            strokeWidth={2.4}
          />
          {point && (
            <ReferenceDot x={point.x} y={point.y} r={5} fill="#de7444" />
          )}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
