import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import type { Vec } from "../physics/vector";
export interface SceneData {
  markers?: { position: Vec; color: string; label?: string; radius?: number }[];
  lines?: { points: Vec[]; color: string }[];
  arrows?: { position: Vec; direction: Vec; color: string }[];
  surfaces?: { vertices: number[]; color: string }[];
  boxes?: { position: Vec; size: Vec; color: string; opacity?: number }[];
}
const v3 = (v: Vec) => new THREE.Vector3(...v);
function dispose(group: THREE.Object3D) {
  group.traverse((obj) => {
    const m = obj as THREE.Mesh;
    if (m.geometry) m.geometry.dispose();
    if (m.material) {
      for (const mat of Array.isArray(m.material) ? m.material : [m.material]) {
        const tex = (mat as THREE.SpriteMaterial).map;
        tex?.dispose();
        mat.dispose();
      }
    }
  });
  group.clear();
}
function label(text: string, position: Vec, color: string) {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 96;
  const ctx = c.getContext("2d")!;
  ctx.font = "bold 48px sans-serif";
  ctx.textAlign = "center";
  ctx.fillStyle = color;
  ctx.fillText(text, 128, 62);
  const sprite = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: new THREE.CanvasTexture(c),
      depthTest: false,
    }),
  );
  sprite.position.copy(v3(position));
  sprite.scale.set(0.85, 0.32, 1);
  return sprite;
}
export function Scene({
  data,
  trail = [],
  particle,
  title = "Escena 3D",
  axisUnit = "m",
}: {
  data: SceneData;
  trail?: Vec[];
  particle?: Vec;
  title?: string;
  axisUnit?: string;
}) {
  const host = useRef<HTMLDivElement>(null),
    world = useRef<{
      root: THREE.Group;
      dynamic: THREE.Group;
      camera: THREE.PerspectiveCamera;
      controls: OrbitControls;
    } | null>(null),
    [error, setError] = useState("");
  useEffect(() => {
    const el = host.current!;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    } catch {
      setError(
        "WebGL no está disponible. Activa la aceleración gráfica del navegador; los cálculos y la vista 2D siguen disponibles.",
      );
      return;
    }
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.setClearColor("#101f2e");
    el.appendChild(renderer.domElement);
    const scene = new THREE.Scene(),
      camera = new THREE.PerspectiveCamera(43, 1, 0.01, 500);
    camera.position.set(6, 5, 8);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.minDistance = 0.4;
    controls.maxDistance = 100;
    const root = new THREE.Group(),
      dynamic = new THREE.Group();
    scene.add(root, dynamic, new THREE.AmbientLight(0xffffff, 2));
    const grid = new THREE.GridHelper(8, 16, 0x395263, 0x243b4b);
    grid.rotation.x = Math.PI / 2;
    scene.add(grid, new THREE.AxesHelper(3.6));
    scene.add(
      label(`x (${axisUnit})`, [3.8, 0, 0], "#ff9892"),
      label(`y (${axisUnit})`, [0, 3.8, 0], "#a4df9a"),
      label(`z (${axisUnit})`, [0, 0, 3.8], "#8dbaff"),
    );
    world.current = { root, dynamic, camera, controls };
    const observer = new ResizeObserver(() => {
      const w = el.clientWidth,
        h = el.clientHeight;
      renderer.setSize(w, h);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    });
    observer.observe(el);
    let raf = 0;
    const render = () => {
      controls.update();
      renderer.render(scene, camera);
      raf = requestAnimationFrame(render);
    };
    render();
    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
      controls.dispose();
      dispose(scene);
      renderer.dispose();
      renderer.domElement.remove();
      world.current = null;
    };
  }, [axisUnit]);
  useEffect(() => {
    const w = world.current;
    if (!w) return;
    dispose(w.root);
    for (const m of data.markers ?? []) {
      const mesh = new THREE.Mesh(
        new THREE.SphereGeometry(m.radius ?? 0.11, 20, 12),
        new THREE.MeshBasicMaterial({ color: m.color }),
      );
      mesh.position.copy(v3(m.position));
      w.root.add(mesh);
      if (m.label)
        w.root.add(
          label(
            m.label,
            [m.position[0], m.position[1] + 0.3, m.position[2]],
            m.color,
          ),
        );
    }
    for (const l of data.lines ?? []) {
      if (l.points.length < 2) continue;
      w.root.add(
        new THREE.Line(
          new THREE.BufferGeometry().setFromPoints(l.points.map(v3)),
          new THREE.LineBasicMaterial({
            color: l.color,
            transparent: true,
            opacity: 0.7,
          }),
        ),
      );
    }
    for (const a of data.arrows ?? []) {
      const d = v3(a.direction);
      if (d.length() < 1e-25) continue;
      w.root.add(
        new THREE.ArrowHelper(
          d.normalize(),
          v3(a.position),
          0.32,
          a.color,
          0.1,
          0.06,
        ),
      );
    }
    for (const s of data.surfaces ?? []) {
      const g = new THREE.BufferGeometry();
      g.setAttribute(
        "position",
        new THREE.Float32BufferAttribute(s.vertices, 3),
      );
      g.computeVertexNormals();
      w.root.add(
        new THREE.Mesh(
          g,
          new THREE.MeshBasicMaterial({
            color: s.color,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0.18,
            depthWrite: false,
          }),
        ),
      );
    }
    for (const b of data.boxes ?? []) {
      const m = new THREE.Mesh(
        new THREE.BoxGeometry(...b.size),
        new THREE.MeshBasicMaterial({
          color: b.color,
          transparent: !!b.opacity,
          opacity: b.opacity ?? 1,
        }),
      );
      m.position.copy(v3(b.position));
      w.root.add(m);
    }
  }, [data]);
  useEffect(() => {
    const w = world.current;
    if (!w) return;
    dispose(w.dynamic);
    if (trail.length > 1)
      w.dynamic.add(
        new THREE.Line(
          new THREE.BufferGeometry().setFromPoints(trail.map(v3)),
          new THREE.LineBasicMaterial({ color: "#ffe18c" }),
        ),
      );
    if (particle) {
      const m = new THREE.Mesh(
        new THREE.SphereGeometry(0.08),
        new THREE.MeshBasicMaterial({ color: "#ffe18c" }),
      );
      m.position.copy(v3(particle));
      w.dynamic.add(m);
    }
  }, [trail, particle]);
  return (
    <div className="scene-frame">
      <div ref={host} className="scene" role="img" aria-label={title} />
      {error && (
        <p role="alert" className="scene-error">
          {error}
        </p>
      )}
      <div className="scene-help">
        Arrastra: rotar · rueda: zoom · botón derecho: desplazar
      </div>
      <button
        className="camera-reset"
        onClick={() => {
          const w = world.current;
          if (w) {
            w.camera.position.set(6, 5, 8);
            w.controls.target.set(0, 0, 0);
            w.controls.update();
          }
        }}
      >
        Centrar vista
      </button>
    </div>
  );
}
